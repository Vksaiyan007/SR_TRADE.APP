# 🚀 SR TRADE APK - Build Instructions

## Option 1: Using Buildozer (Recommended)

### Prerequisites (Ubuntu/WSL):
```bash
sudo apt update
sudo apt install -y openjdk-11-jdk python3-dev libffi-dev libssl-dev libjpeg-dev zlib1g-dev
pip install buildozer cython
```

### Build Command:
```bash
cd /path/to/srtrade_apk
buildozer android debug
```

**Output**: `bin/srtrade-2.0-debug.apk`

### First Build:
- Takes 10-30 minutes
- Downloads Android SDK (~2GB)
- Requires 5GB+ disk space
- Only first build is slow

### Build Release (requires keystore):
```bash
buildozer android release
```

---

## Option 2: Using Python for Android (P4A)

### Install:
```bash
pip install python-for-android
```

### Build:
```bash
bash build_with_p4a.sh
```

---

## Option 3: Online Builder Service

Use web-based builder if local build fails:
- https://appmaker.kivy.org/ (Kivy)
- https://anvil.works/ (Alternative)
- Upload files and download APK

---

## Installation on Android Device

### Method 1: USB Cable
```bash
adb install bin/srtrade-2.0-debug.apk
```

### Method 2: Direct Download
1. Transfer APK to phone
2. Open file manager
3. Tap APK file
4. Allow unknown sources if needed
5. Install

### Method 3: QR Code
- Host APK on web server
- Generate QR code
- Scan with phone

---

## Troubleshooting

### "Java not found"
```bash
sudo apt install openjdk-11-jdk
java -version  # Verify
```

### "Android SDK not found"
```bash
# Force fresh download:
rm -rf ~/.buildozer
buildozer android debug
```

### Build stuck?
```bash
# Check logs:
tail -f .buildozer/android/platform/build-*/build/logs/python-build.log
```

### "Permission denied"
- Use Linux/WSL (not Windows CMD)
- Don't use sudo for buildozer

---

## System Requirements

| Requirement | Minimum | Recommended |
|---|---|---|
| RAM | 4GB | 8GB+ |
| Disk | 10GB | 20GB+ |
| Internet | 10Mbps | 50Mbps+ |
| OS | Linux/WSL2 | Ubuntu 20.04+ |

---

## App Features

✅ Live Trading Charts  
✅ Technical Indicators  
✅ Trade Journal  
✅ Watchlist  
✅ Options Analysis  
✅ Analytics Dashboard  
✅ User Settings  
✅ Educational Content  

---

## Support

**GitHub**: https://github.com/Vksaiyan007/SR_TRADE.APP

**Issues**: Create issue with build logs

**Version**: 2.0  
**License**: MIT
