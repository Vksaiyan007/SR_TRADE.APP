from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.scrollview import ScrollView
from kivy.core.window import Window
from kivy.graphics import Color, Rectangle

Window.size = (400, 800)

class SRTradeApp(App):
    def build(self):
        main_layout = BoxLayout(orientation='vertical', padding=10, spacing=5)
        
        # Title
        with main_layout.canvas.before:
            Color(0.1, 0.3, 0.6, 1)
            Rectangle(size=main_layout.size, pos=main_layout.pos)
        
        title = Label(
            text='[b]SR TRADE[/b]\n[size=14]Professional Trading v2.0[/size]',
            markup=True,
            size_hint_y=0.15,
            color=(1, 1, 1, 1)
        )
        main_layout.add_widget(title)
        
        # Features Grid
        scroll = ScrollView(size_hint=(1, 0.75))
        
        grid = GridLayout(cols=2, spacing=15, size_hint_y=None, padding=10)
        grid.bind(minimum_height=grid.setter('height'))
        
        features = {
            '📊 Live Charts': 'Real-time market data',
            '📈 Indicators': 'RSI, MACD, MA, Bollinger',
            '💼 Trade Journal': 'Track all trades & P&L',
            '🎯 Watchlist': 'Custom watch lists',
            '📋 Options': 'Options chain analysis',
            '📊 Analytics': 'Performance analytics',
            '⚙️ Settings': 'User preferences',
            '📚 Education': 'Trading resources'
        }
        
        for title, desc in features.items():
            btn = Button(
                text=f'{title}\n[size=10]{desc}[/size]',
                markup=True,
                size_hint_y=None,
                height=80
            )
            grid.add_widget(btn)
        
        scroll.add_widget(grid)
        main_layout.add_widget(scroll)
        
        # Footer
        footer = Label(
            text='v2.0 | SR Analytics | Trading Platform',
            size_hint_y=0.1,
            font_size='10sp',
            color=(0.7, 0.7, 0.7, 1)
        )
        main_layout.add_widget(footer)
        
        return main_layout

if __name__ == '__main__':
    SRTradeApp().run()
