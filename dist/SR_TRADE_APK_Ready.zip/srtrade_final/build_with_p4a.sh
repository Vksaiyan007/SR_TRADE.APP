#!/bin/bash

echo "Building with Python for Android..."

pip install python-for-android

p4a apk \
    --requirements=python3,kivy,pandas,numpy,matplotlib,yfinance,requests \
    --name="SR TRADE" \
    --package=com.srtrade.trading \
    --version 2.0 \
    --bootstrap=sdl2 \
    --permission INTERNET \
    --permission ACCESS_NETWORK_STATE \
    --presplash_color=#1a4d7f \
    main.py

echo "APK created in current directory"
